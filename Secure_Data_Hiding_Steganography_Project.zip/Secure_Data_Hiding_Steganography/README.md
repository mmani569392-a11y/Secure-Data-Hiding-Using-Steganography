# Secure Data Hiding Using Steganography

A Python/Flask BCA project inspired by the supplied reference project.

## Project flow

### Sender Side
1. Select a cover image.
2. Enter the secret message.
3. Enter Prime 1 and Prime 2, matching the reference UI.
4. Enter a password.
5. Encrypt the message using AES-256-GCM.
6. Base64-encode the encrypted payload.
7. Hide the payload in the image using LSB steganography.
8. Save the result as a PNG.

### Receiver Side
1. Select the encoded image.
2. Enter the same Prime 1, Prime 2 and password.
3. Extract the hidden payload using LSB.
4. Base64-decode it.
5. Decrypt it with AES-256-GCM.
6. Display the original secret message.

## Technology
- Python
- Flask
- Pillow
- Cryptography
- HTML
- CSS
- LSB Steganography
- Base64
- AES-256-GCM
- PBKDF2-HMAC-SHA256

## Installation

Open Command Prompt / PowerShell in this folder:

```text
python -m venv venv
```

Windows:

```text
venv\Scripts\activate
```

Install packages:

```text
pip install -r requirements.txt
```

Run:

```text
python app.py
```

Open the address shown by Flask, normally:

```text
http://127.0.0.1:5000
```

## Test values

For a first test use:

- Prime 1: `991`
- Prime 2: `997`
- Password: `secure123`
- Message: `This is my secret message.`

Use a normal PNG/JPG/BMP photo as the cover image.

**Important:** the encoded output is always written as PNG. Do not convert the encoded PNG to JPEG because JPEG compression can damage LSB data.

## Resume description

**Secure Data Hiding Using Steganography**
- Developed a Python Flask web application for hiding confidential text inside digital images using LSB steganography.
- Implemented AES-256-GCM authenticated encryption and PBKDF2-HMAC-SHA256 key derivation before embedding the payload.
- Built separate sender and receiver workflows with image upload, encryption, extraction, decryption and downloadable encoded-image functionality.
- Used Pillow for pixel-level image processing and Base64 encoding for safe payload transport.

## Reference mapping

The supplied reference project contains:
- Home page with Sender Side / Receiver Side
- Flask connectivity
- Prime 1 / Prime 2 fields
- Base64 section
- AES-labelled encryption/decryption section
- PIL-based LSB steganography
- Encode and Decode functions
- Browser screenshots of Home, Sender and Receiver pages

This new implementation keeps that overall project structure and user-facing workflow while using a working, self-contained cryptographic implementation.
